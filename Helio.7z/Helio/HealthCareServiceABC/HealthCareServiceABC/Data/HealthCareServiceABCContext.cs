﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HealthCareServiceABC.Models;

namespace HealthCareServiceABC.Models
{
    public class HealthCareServiceABCContext : DbContext
    {
        public HealthCareServiceABCContext (DbContextOptions<HealthCareServiceABCContext> options)
            : base(options)
        {
        }

        public DbSet<HealthCareServiceABC.Models.Patient> Patient { get; set; }

        public DbSet<HealthCareServiceABC.Models.ServiceConsultation> ServiceConsultation { get; set; }

        public DbSet<HealthCareServiceABC.Models.Invoice> Invoice { get; set; }
    }
}
