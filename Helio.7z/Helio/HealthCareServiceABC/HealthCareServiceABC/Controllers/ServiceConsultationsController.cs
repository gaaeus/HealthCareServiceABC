﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HealthCareServiceABC.Models;

namespace HealthCareServiceABC.Controllers
{
    public class ServiceConsultationsController : Controller
    {
        private readonly HealthCareServiceABCContext _context;

        public ServiceConsultationsController(HealthCareServiceABCContext context)
        {
            _context = context;
        }

        // GET: ServiceConsultations
        public async Task<IActionResult> Index()
        {
            return View(await _context.ServiceConsultation.ToListAsync());
        }

        // GET: ServiceConsultations/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var serviceConsultation = await _context.ServiceConsultation
                .FirstOrDefaultAsync(m => m.ID == id);
            if (serviceConsultation == null)
            {
                return NotFound();
            }

            return View(serviceConsultation);
        }

        // GET: ServiceConsultations/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ServiceConsultations/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,PatientID")] ServiceConsultation serviceConsultation)
        {
            if (ModelState.IsValid)
            {
                _context.Add(serviceConsultation);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(serviceConsultation);
        }

        // GET: ServiceConsultations/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var serviceConsultation = await _context.ServiceConsultation.FindAsync(id);
            if (serviceConsultation == null)
            {
                return NotFound();
            }
            return View(serviceConsultation);
        }

        // POST: ServiceConsultations/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,PatientID")] ServiceConsultation serviceConsultation)
        {
            if (id != serviceConsultation.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(serviceConsultation);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ServiceConsultationExists(serviceConsultation.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(serviceConsultation);
        }

        // GET: ServiceConsultations/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var serviceConsultation = await _context.ServiceConsultation
                .FirstOrDefaultAsync(m => m.ID == id);
            if (serviceConsultation == null)
            {
                return NotFound();
            }

            return View(serviceConsultation);
        }

        // POST: ServiceConsultations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var serviceConsultation = await _context.ServiceConsultation.FindAsync(id);
            _context.ServiceConsultation.Remove(serviceConsultation);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ServiceConsultationExists(int id)
        {
            return _context.ServiceConsultation.Any(e => e.ID == id);
        }
    }
}
