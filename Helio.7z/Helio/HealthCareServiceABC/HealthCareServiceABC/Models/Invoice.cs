﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCareServiceABC.Models
{
    public class Invoice
    {
        [Key]
        public int ID { get; set; }

        public string ServiceConsultationID { get; set; }

        public string InvoiceID { get; set; }

        public DateTime CreatedAt { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public Decimal Fee { get; set; }
    }
}