﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCareServiceABC.Models
{
    public enum PatientGender
    {
        [Description("Not Disclosed")]
        NonDisclosed = 0,
        [Description("Male")]
        Male = 1,
        [Description("Female")]
        Female = 2
    }

    public class Patient
    {
        [Key]
        public int ID { get; set; }

        [Required]
        [Display(Name = "First Name")]
         public string FirstName { get; set; }

        [Required]
        public string Surname { get; set; }

        public PatientGender Gender { get; set; }

        public DateTime DOB { get; set; }

        [Required]
        [Display(Name = "Address Line 1")]
        public string AddressLine1 { get; set; }

        [Display(Name = "Address Line 2")]
        public string AddressLine2 { get; set; }

        [Display(Name = "Address Line 3")]
        public string AddressLine3 { get; set; }

        [Required]
        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }

        public virtual IEnumerable<ServiceConsultation> Consultations { get; set; }

        public virtual IEnumerable<Invoice> Invoices { get; set; }

        bool Deleted { get; set; }
    }
}
