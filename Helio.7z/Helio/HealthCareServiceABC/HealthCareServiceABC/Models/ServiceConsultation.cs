﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCareServiceABC.Models
{
    public class ServiceConsultation
    {
        [Key]
        public int ID { get; set; }

        public int PatientID { get; set; }

        public DateTime CreatedAt { get; set; }

        public bool PresentingSymptoms { get; set; }

        public string SymptomsDescription { get; set; }

        public string IndicationsAndAdvice { get; set; }

        public string MedicationGiven { get; set; }

        public string Comments { get; set; }
    }
}
